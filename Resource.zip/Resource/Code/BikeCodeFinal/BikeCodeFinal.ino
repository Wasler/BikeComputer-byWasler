#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <Preferences.h>

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define HALL_PIN 7      
#define BUTTON_PIN 2    

Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);
Preferences preferences;

const float WHEEL_CIRCUMFERENCE = 2.326; 
volatile unsigned long lastTime = 0;
volatile float currentSpeed = 0;
float totalKm = 0;
unsigned long tripSeconds = 0; 
unsigned long lastTick = 0;
unsigned long pulseCount = 0;

int hours = 12;
int minutes = 0;
unsigned long lastMs = 0;

enum Mode { RIDE, SET_HOURS, SET_MINS };
Mode currentMode = RIDE;

void IRAM_ATTR onImpulse() {
  unsigned long currentTime = millis();
  unsigned long duration = currentTime - lastTime;
  if (duration > 40) { 
    currentSpeed = (WHEEL_CIRCUMFERENCE / (duration / 1000.0)) * 3.6;
    lastTime = currentTime;
    pulseCount++;
  }
}

void setup() {
  pinMode(HALL_PIN, INPUT_PULLUP);
  pinMode(BUTTON_PIN, INPUT_PULLUP);
  
  preferences.begin("bike-data", false);
  totalKm = preferences.getFloat("totalKm", 0.0);
  tripSeconds = preferences.getUInt("tripSeconds", 0);
  hours = preferences.getInt("rtc_h", 12);
  minutes = preferences.getInt("rtc_m", 0);

  attachInterrupt(digitalPinToInterrupt(HALL_PIN), onImpulse, FALLING);
  Wire.begin(8, 9);
  display.begin(SSD1306_SWITCHCAPVCC, 0x3C);
  lastTick = millis();
  lastMs = millis();
}

void handleButton() {
  static unsigned long btnDown = 0;
  static int clickCount = 0;
  static unsigned long lastClickTime = 0;
  static bool handled2s = false;
  bool btnState = (digitalRead(BUTTON_PIN) == LOW);

  if (btnState) {
    if (btnDown == 0) {
        btnDown = millis();
        handled2s = false;
    }
    
    unsigned long holdTime = millis() - btnDown;

    // Переход (Next) — зажатие на 2 секунды
    if (holdTime >= 2000 && holdTime < 5000 && !handled2s) {
      if (currentMode == RIDE) currentMode = SET_HOURS;
      else if (currentMode == SET_HOURS) currentMode = SET_MINS;
      else if (currentMode == SET_MINS) {
        currentMode = RIDE;
        preferences.putInt("rtc_h", hours);
        preferences.putInt("rtc_m", minutes);
      }
      handled2s = true; 
    }
    
    // Сброс (Reset) — зажатие на 5 секунд
    if (holdTime >= 5000) {
      totalKm = 0; tripSeconds = 0;
      preferences.putFloat("totalKm", 0.0);
      preferences.putUInt("tripSeconds", 0);
      display.clearDisplay();
      display.setTextSize(2);
      display.setCursor(30, 25); display.print("RESET");
      display.display();
      btnDown = 0; // Сбрасываем, чтобы не срабатывало по кругу
    }
  } else {
    if (btnDown > 0) {
      unsigned long holdTime = millis() - btnDown;
      if (holdTime < 1500) { // Если отпустили раньше 2 сек — считаем клики
        clickCount++;
        lastClickTime = millis();
      }
      btnDown = 0;
    }
  }

  // Обработка кликов (через 300мс после последнего нажатия)
  if (clickCount > 0 && (millis() - lastClickTime > 300)) {
    if (currentMode != RIDE) {
      if (clickCount == 1) { // 1 клик = Вверх
        if (currentMode == SET_HOURS) { hours++; if(hours > 23) hours = 0; }
        else if (currentMode == SET_MINS) { minutes++; if(minutes > 59) minutes = 0; }
      } 
      else if (clickCount == 2) { // 2 клика = Вниз
        if (currentMode == SET_HOURS) { hours--; if(hours < 0) hours = 23; }
        else if (currentMode == SET_MINS) { minutes--; if(minutes < 0) minutes = 59; }
      }
    }
    clickCount = 0;
  }
}

void loop() {
  handleButton();

  if (millis() - lastMs >= 60000) {
    minutes++;
    if (minutes > 59) { minutes = 0; hours++; }
    if (hours > 23) hours = 0;
    lastMs = millis();
  }

  if (millis() - lastTick >= 1000) {
    tripSeconds++;
    lastTick = millis();
    if (tripSeconds % 60 == 0) preferences.putUInt("tripSeconds", tripSeconds);
  }

  if (millis() - lastTime > 2000) currentSpeed = 0;

  if (pulseCount >= (100 / WHEEL_CIRCUMFERENCE)) {
    totalKm += (pulseCount * WHEEL_CIRCUMFERENCE) / 1000.0;
    pulseCount = 0;
    preferences.putFloat("totalKm", totalKm);
  }

  static unsigned long lastDisp = 0;
  if (millis() - lastDisp > 300) {
    updateDisplay();
    lastDisp = millis();
  }
}

void updateDisplay() {
  display.clearDisplay();
  display.setTextColor(WHITE);
  
  // Текущее время (Правый верхний угол)
  display.setTextSize(1);
  display.setCursor(95, 0);
  if(hours < 10) display.print("0"); display.print(hours);
  display.print(":");
  if(minutes < 10) display.print("0"); display.print(minutes);

  if (currentMode != RIDE) {
    display.setCursor(0, 0);
    display.print(currentMode == SET_HOURS ? "> SET HOURS" : "> SET MINS");
  } else {
    display.setCursor(0, 0);
    display.print("BIKE READY");
  }

  // Скорость
  display.setTextSize(4);
  display.setCursor(10, 18);
  display.print(currentSpeed, 1);
  display.setTextSize(1);
  display.setCursor(100, 40);
  display.print("km/h");

  // Таймер поездки (Правый нижний угол)
  int t_mins = (tripSeconds / 60) % 60;
  int t_hrs = (tripSeconds / 3600);
  display.setCursor(90, 56);
  if(t_hrs < 10) display.print("0"); display.print(t_hrs);
  display.print("h ");
  if(t_mins < 10) display.print("0"); display.print(t_mins);
  display.print("m");

  // ОДОМЕТР (Нижний левый + надпись km)
  display.drawLine(0, 52, 127, 52, WHITE);
  display.setCursor(0, 56);
  display.print("ODO:"); 
  display.print(totalKm, 1);
  display.print(" km");
  
  display.display();
}