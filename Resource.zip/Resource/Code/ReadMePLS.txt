Please install in Arduino IDE library:
1.Adafruit_GFX
2.Adafruit_SSD1306
3.Preferences
4.Wire